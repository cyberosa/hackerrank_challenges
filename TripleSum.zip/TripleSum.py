#!/bin/python3

import math
import os
import random
import re
import sys
from collections import deque


def find_pairs_with_q(q, c, pairs, seen):
    # check if q is a key in pairs -> already computed
    if q in pairs.keys():
        return pairs, seen

    # check if we have elements in seen
    # update the list using q value as the max allowed
    # in that list
    if len(seen) > 0:
        print("using seen")
        # these values are ordered and unique
        # use deque to remove last element
        d_seen = deque(seen)
        last = d_seen[-1]
        # only if the last position is bigger we trip
        if last > q:
            while last > q:
                d_seen.pop()
                if len(d_seen) > 0:
                    last = d_seen[-1]
                else:
                    break
            if last <= q:
                seen = list(d_seen)
            else:
                return pairs, []
        pairs[q] = seen
        print(pairs)
        print(seen)
        return pairs, seen

    # traverse c for the first time
    #  while lower values found
    i = 0
    len_c = len(c)
    while i < len_c and c[i] <= q:
        if q in pairs.keys():
            tmp = pairs[q]
            tmp.append(c[i])
            # duplicates?
            pairs[q] = list(set(tmp))
        else:  # new key
            pairs[q] = [c[i]]

        seen.append(c[i])
        i += 1
    print("using array")
    print(pairs)
    print(seen)
    # remove duplicates
    if len(seen) > 0:
        seen = list(set(seen))
    return pairs, seen


# Complete the triplets function below.
def triplets(a, b, c):
    count = 0
    # max element of array b, used to stop traversing a and c
    max_b = b[-1]  # last element if b is ordered
    bc_pairs = dict()
    ab_pairs = dict()
    len_b = len(b)
    seen_c = []  # list with seen elements of array c

    # traverse b in reverse order
    for i_b in range(len_b - 1, -1, -1):
        q = b[i_b]
        print("q={}".format(q))
        bc_pairs, seen_c = find_pairs_with_q(q, c, bc_pairs, seen_c)
        # if we run out of seen values --> no need to go on iterating
        if len(seen_c) == 0:
            continue
    # find_pairs_with_q(q,a)
    print("finding ab pairs")
    # traverse now the keys in bc_pairs dict to find ab_pairs
    # bc_keys are already in reverse order
    seen_a = []
    for b_key in bc_pairs.keys():
        q = b_key
        print("q={}".format(q))
        ab_pairs, seen_a = find_pairs_with_q(q, a, ab_pairs, seen_a)
        if len(seen_a) == 0:
            continue

    # now use both dictionaries to compute the total count
    for key_b in ab_pairs.keys():
        list_found1 = ab_pairs[key_b]
        list_found2 = bc_pairs[key_b]
        count += len(list_found1) * len(list_found2)

    return count


if __name__ == '__main__':
    fptr = open(os.environ['OUTPUT_PATH'], 'w')

    lenaLenbLenc = input().split()

    lena = int(lenaLenbLenc[0])

    lenb = int(lenaLenbLenc[1])

    lenc = int(lenaLenbLenc[2])

    arra = list(map(int, input().rstrip().split()))

    arrb = list(map(int, input().rstrip().split()))

    arrc = list(map(int, input().rstrip().split()))

    ans = triplets(arra, arrb, arrc)

    fptr.write(str(ans) + '\n')

    fptr.close()
