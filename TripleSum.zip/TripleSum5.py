#!/bin/python3

import math
import os
import random
import re
import sys

# Complete the triplets function below.
def triplets(a, b, c):
    a = list(set(a))
    b = list(set(b))
    c = list(set(c))
    a.sort()
    b.sort()
    c.sort()
    count = 0
    
    bc_pairs = dict()
    ab_pairs = dict()
    len_a = len(a)
    len_b = len(b)
    len_c = len(c)
    a_i = 0
    b_i = 0
    c_i = 0
    
    # traverse b
    while b_i < len_b:
        q = b[b_i]
        print("q={}".format(q))
        # find ab_pairs
        while a_i < len_a and a[a_i] <= q:
            a_i += 1
        # find bc_pairs
        while c_i < len_c and c[c_i] <= q:
            c_i += 1 
        count += a_i * c_i
        b_i += 1
        
    return count

if __name__ == '__main__':
    fptr = open(os.environ['OUTPUT_PATH'], 'w')

    lenaLenbLenc = input().split()

    lena = int(lenaLenbLenc[0])

    lenb = int(lenaLenbLenc[1])

    lenc = int(lenaLenbLenc[2])

    arra = list(map(int, input().rstrip().split()))

    arrb = list(map(int, input().rstrip().split()))

    arrc = list(map(int, input().rstrip().split()))

    ans = triplets(arra, arrb, arrc)

    fptr.write(str(ans) + '\n')

    fptr.close()
