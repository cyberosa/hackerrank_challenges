#!/bin/python3

import math
import os
import random
import re
import sys

def wordListToFreqDict(wordlist, vocabulary):
    wordfreq = [wordlist.count(p) for p in vocabulary]
    return dict(list(zip(vocabulary,wordfreq)))

# Complete the checkMagazine function below.
def checkMagazine(magazine, note):
    unique_words = set(note)
    vocabulary = set(magazine)

    if (len(vocabulary) < len(unique_words)):
        return 'No'

    for word in unique_words:
        count = magazine.count(word)
        if count == 0:
            return 'No'
        elif count < note.count(word):
            return 'No'
    return 'Yes'

if __name__ == '__main__':
    mn = input().split()

    m = int(mn[0])

    n = int(mn[1])

    magazine = input().rstrip().split()

    note = input().rstrip().split()

    print(checkMagazine(magazine, note))
