#!/bin/python3

import math
import os
import random
import re
import sys
from collections import Counter

def wordListToFreqDict(wordlist, vocabulary):
    wordfreq = [wordlist.count(p) for p in vocabulary]
    return dict(list(zip(vocabulary,wordfreq)))

# Complete the checkMagazine function below.
def checkMagazine(magazine, note):
    #print(Counter(note))
    #print(Counter(magazine))
    return (Counter(note) - Counter(magazine)) == {}

if __name__ == '__main__':
    mn = input().split()

    m = int(mn[0])

    n = int(mn[1])

    magazine = input().rstrip().split()

    note = input().rstrip().split()

    if checkMagazine(magazine, note) == True:
        print('Yes')
    else:
        print('No')
