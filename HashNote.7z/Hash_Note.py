#!/bin/python3

import math
import os
import random
import re
import sys

def wordListToFreqDict(wordlist):
    wordfreq = [wordlist.count(p) for p in wordlist]
    return dict(list(zip(wordlist,wordfreq)))

# Complete the checkMagazine function below.
def checkMagazine(magazine, note):
    note_dict = wordListToFreqDict(note)
    res = " ".join(magazine)
    #print(note_dict)
    for word in note_dict.keys():
        freq = note_dict[word]
        if len(re.findall(word,res)) < freq:
            return 'No'
    return 'Yes'

if __name__ == '__main__':
    mn = input().split()

    m = int(mn[0])

    n = int(mn[1])

    magazine = input().rstrip().split()

    note = input().rstrip().split()

    print(checkMagazine(magazine, note))
