#!/bin/python3

import math
import os
import random
import re
import sys

# Complete the arrayManipulation function below.
def arrayManipulation(n, queries):
    sum_dict = dict()
    max_value = 0
    # initialize the dictionary
    for i in range(n):
        sum_dict[i] = 0
    for oper in queries:
        # extract the operation as a list of 3 integers
        start, end, value = oper
        for j in range(start-1,end):
            sum_dict[j] = sum_dict[j] + value
            if sum_dict[j] > max_value: max_value = sum_dict[j]
    return max_value

if __name__ == '__main__':
    fptr = open(os.environ['OUTPUT_PATH'], 'w')

    nm = input().split()

    n = int(nm[0])

    m = int(nm[1])

    queries = []

    for _ in range(m):
        queries.append(list(map(int, input().rstrip().split())))

    result = arrayManipulation(n, queries)

    fptr.write(str(result) + '\n')

    fptr.close()
