#!/bin/python3

import math
import os
import random
import re
import sys

# Complete the arrayManipulation function below.
def arrayManipulation(n, queries):
    # initialize the numpy array
    total = [0] * n
    for i in range(len(queries)):
        # extract the operation as a list of 3 integers
        start, end, value = queries[i]
        # increment value at start of sequence
        total[start-1] += value
        # decrement value at first position after sequence
        if end <= (n-1) : total[end] -= value
        #print(total)
    max_sum = tmp = 0
    for number in total:
        tmp=tmp+number;
        if(max_sum<tmp): max_sum=tmp
    return max_sum

if __name__ == '__main__':
    fptr = open(os.environ['OUTPUT_PATH'], 'w')

    nm = input().split()

    n = int(nm[0])

    m = int(nm[1])

    queries = []

    for _ in range(m):
        queries.append(list(map(int, input().rstrip().split())))

    result = arrayManipulation(n, queries)

    fptr.write(str(result) + '\n')

    fptr.close()
