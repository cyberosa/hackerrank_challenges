#!/bin/python3

import math
import os
import random
import re
import sys
from collections import defaultdict

# Complete the whatFlavors function below.
def whatFlavors(n, cost, money):
    complements = defaultdict(int)
    for i, v in enumerate(cost):
        # check if we have the complement already in the hash table
        target = money - v
        seen = list(complements.keys())
        if target not in seen:
            complements[v] = i+1 
        else:
            return [complements[target], i+1]

if __name__ == '__main__':
    t = int(input())
    #fptr = open(os.environ['OUTPUT_PATH'], 'w')
    for t_itr in range(t):
        money = int(input())

        n = int(input())

        cost = list(map(int, input().rstrip().split()))

        result = whatFlavors(n, cost, money)
        print(*result, sep=' ')
        #fptr.write(str(result) + '\n')

    #fptr.close()
