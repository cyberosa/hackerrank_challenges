#!/bin/python3

import math
import os
import random
import re
import sys
from collections import defaultdict

# according to a reference spent value, find in sublist a partner
# to reach the amount money
def find_combination(position, money, candidates, fla_dict):
    ini_spent = fla_dict[position]
    max_spent = 0
    best = [] # if not a perfect match, then return the best pair
    for key in candidates:
        spent = ini_spent+fla_dict[key]
        if spent == money:
            #found
            return [position,key]
        if spent > max_spent:
            max_spent = spent
            best =[position,key]
    return best

# Complete the whatFlavors function below.
def whatFlavors(n, cost, money):
    flavours = defaultdict(int)
    for i in range(n):
        f = cost[i]
        if f < money:
            flavours[i+1] = f
            
    # traverse the selected flavours and find the combination
    # of two flavours that maximixe the cost
    len_fla = len(flavours)
    highest = 0
    selected = []
    for i in range(len_fla):
        candidates = list(flavours.keys())
        current = candidates[i]
        rest = candidates[i+1:]
        check = find_combination(current, money, rest, flavours)
        # only two values
        cost_1 = flavours[check[0]]
        cost_2 = flavours[check[1]]
        if cost_1 + cost_2 == money:
            return check
        if cost_1 + cost_2 > highest:
            highest = cost_1 + cost_2
            selected = check
    # not exact match found
    return selected

if __name__ == '__main__':
    t = int(input())
    #fptr = open(os.environ['OUTPUT_PATH'], 'w')
    for t_itr in range(t):
        money = int(input())

        n = int(input())

        cost = list(map(int, input().rstrip().split()))

        result = whatFlavors(n, cost, money)
        print(*result, sep=' ')
        #fptr.write(str(result) + '\n')

    #fptr.close()
