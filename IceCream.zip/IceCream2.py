#!/bin/python3

import math
import os
import random
import re
import sys
from collections import defaultdict

# according to a reference spent value, find in sublist a partner
# to reach the amount money
def find_combination(position, money, fla_dict):
    candidates = list(fla_dict.keys())
    values = list(fla_dict.values())
    
    current = candidates[position]
    rest = values[position+1:]
    ini_spent = fla_dict[current]
    rest_to_spend = money - ini_spent
                
    # check if in flavours we have the right pair for f
    if rest_to_spend in rest:
        rel_pos = rest.index(rest_to_spend)
        # this position is from the sublist
        key = candidates[position+1+rel_pos]
        return [current,key]
    
    # we need to closest to rest_to_spend
    rest.sort()
    i = -1
    selected = 0
    while i+1 < len(rest):
          i += 1
          if rest[i] < rest_to_spend and rest[i] > selected:
            selected = rest[i]
    rel_pos = rest.index(selected)
    # this position is from the sublist
    key = candidates[position+1+rel_pos]
    return [current,key]

# Complete the whatFlavors function below.
def whatFlavors(n, cost, money):
    flavours = defaultdict(int)
    for i in range(n):
        f = cost[i]
        if f < money:
            flavours[i+1] = f
            
    # traverse the selected flavours and find the combination
    # of two flavours that maximixe the cost
    len_fla = len(flavours)
    highest = 0
    selected = []
    for i in range(len_fla):
        check = find_combination(i, money, flavours)
        # only two values
        cost_1 = flavours[check[0]]
        cost_2 = flavours[check[1]]
        if cost_1 + cost_2 == money:
            return check
        if cost_1 + cost_2 > highest:
            highest = cost_1 + cost_2
            selected = check
    # not exact match found
    return selected

if __name__ == '__main__':
    t = int(input())
    #fptr = open(os.environ['OUTPUT_PATH'], 'w')
    for t_itr in range(t):
        money = int(input())

        n = int(input())

        cost = list(map(int, input().rstrip().split()))

        result = whatFlavors(n, cost, money)
        print(*result, sep=' ')
        #fptr.write(str(result) + '\n')

    #fptr.close()
